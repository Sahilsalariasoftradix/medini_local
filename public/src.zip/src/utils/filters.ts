export const overRideSvgColor = {
    default: "",
    white: "brightness(0) saturate(100%) invert(100%) sepia(100%) saturate(0%) hue-rotate(198deg) brightness(104%) contrast(104%)",
    blue: "sepia(100%) hue-rotate(190deg) saturate(500%)"
  };