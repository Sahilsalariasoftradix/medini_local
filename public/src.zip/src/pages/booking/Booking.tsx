import AvailabilityCalendar from "../../components/Booking/availability-calendar";

const Booking = () => {
  return <div><AvailabilityCalendar /></div>;
};

export default Booking;
