import LoginForm from "../../../components/Auth/Login/LoginForm";

const Login = () => {
  return <LoginForm />;
};

export default Login;
