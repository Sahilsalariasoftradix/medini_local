import ResetPasswordForm from "../../../components/Auth/ResetPassword/ResetPasswordForm";

const ResetPassword = () => {
  return <ResetPasswordForm />;
};

export default ResetPassword;
