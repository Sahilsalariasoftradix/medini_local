import SignUpForm from "../../../components/Auth/SignUp/SignUpForm";

const SignUp = () => {
  return <SignUpForm />;
};

export default SignUp;
