import AvailabilityCalendar from "../../components/Schedule/availability-calendar";

const Schedule = () => {
  return <div><AvailabilityCalendar /></div>;
};

export default Schedule;
