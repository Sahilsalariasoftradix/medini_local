
const VerifyEmail = () => {
  return (
    <div>dfgfdgd  </div>
  )
}

export default VerifyEmail